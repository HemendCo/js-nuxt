This is a repo to accompany a tutorial on building a Nuxt module on [Medium](https://medium.com/carepenny/creating-a-nuxt-module-1c6e3cdf1037).
